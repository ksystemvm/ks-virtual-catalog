from rest_framework import viewsets
from .models import Country, State, Currency, ExchangeRate
from .serializers import CountrySerializer, StateSerializer, CurrencySerializer, ExchangeRateSerializer

class CountryViewSet(viewsets.ModelViewSet):
    queryset = Country.objects.filter(is_active=True) # Por defecto solo mostramos los activos
    serializer_class = CountrySerializer

class StateViewSet(viewsets.ModelViewSet):
    queryset = State.objects.filter(is_active=True)
    serializer_class = StateSerializer

class CurrencyViewSet(viewsets.ModelViewSet):
    queryset = Currency.objects.filter(is_active=True)
    serializer_class = CurrencySerializer

class ExchangeRateViewSet(viewsets.ModelViewSet):
    queryset = ExchangeRate.objects.all()
    serializer_class = ExchangeRateSerializer