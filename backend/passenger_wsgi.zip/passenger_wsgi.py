import os
import sys

# Añade la ruta del proyecto al path del sistema
sys.path.insert(0, os.path.dirname(__file__))

# Configura la variable de entorno para settings
os.environ['DJANGO_SETTINGS_MODULE'] = 'config.settings'

# Importa la aplicación WSGI de Django
from django.core.wsgi import get_wsgi_application
application = get_wsgi_application()